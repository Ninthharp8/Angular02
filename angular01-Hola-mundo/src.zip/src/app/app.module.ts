import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import{HttpClientModule}from'@angular/common/http'; // se agrego esto
import { BusquedaService } from './servicios/busqueda.service';// al final ded todo se agreg'o esto


@NgModule({
  declarations: [
    AppComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule // se agrego esto
  ],
  providers: [BusquedaService],
  bootstrap: [AppComponent]
})
export class AppModule { }
